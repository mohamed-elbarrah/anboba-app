"use client";
import { useRef, useState } from "react";
import Link from "next/link";
import {
  AlertCircle,
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Check,
  Copy,
  GripVertical,
  Plus,
  Save,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  discardFormDraft,
  publishForm,
  saveFormDraft,
} from "@/features/forms/actions";
import type { FormRendererKey } from "@/features/forms/registry-core";
import type { NormalizedRevision } from "@/features/forms/normalized";
import {
  genericFieldTypes,
  genericValidationPresets,
  genericFieldWidths,
} from "@/features/forms/client-schema";
type Locale = "ar" | "en";
type Initial = {
  config: unknown;
  normalized: NormalizedRevision;
  publishedConfig: unknown;
  revisionToken: string;
} | null;
type Props = {
  formId: string;
  formKey: string;
  rendererKey: FormRendererKey;
  kind: "system" | "user";
  locales: Record<Locale, Initial>;
  references: Array<{ locale: Locale; label: string; href: string }>;
};
type Field = NormalizedRevision["fields"][number];
type Local = NormalizedRevision["localizations"][number];
const typeNames: Record<string, string> = {
  text: "Text",
  email: "Email",
  phone: "Phone",
  textarea: "Textarea",
  select: "Select",
  radio: "Radio",
  checkbox: "Checkbox",
  number: "Number",
  date: "Date",
  file: "File (protected)",
};
const arabicTypeNames: Record<string, string> = {
  text: "نص",
  email: "بريد إلكتروني",
  phone: "هاتف",
  textarea: "نص طويل",
  select: "قائمة اختيار",
  radio: "اختيار واحد",
  checkbox: "اختيارات متعددة",
  number: "رقم",
  date: "تاريخ",
  file: "ملف (محمي)",
};
const validationNames: Record<Locale, Record<string, string>> = {
  en: Object.fromEntries(
    genericValidationPresets.map((value) => [value, value]),
  ),
  ar: {
    "validation.fullNameMin": "الاسم — الحد الأدنى",
    "validation.fullNameMax": "الاسم — الحد الأقصى",
    "validation.phone": "رقم الهاتف",
    "validation.messageMin": "الرسالة — الحد الأدنى",
    "validation.messageMax": "الرسالة — الحد الأقصى",
    "validation.email": "البريد الإلكتروني",
    "validation.city": "المدينة",
    "validation.experience": "سنوات الخبرة",
    "validation.transport": "وسيلة النقل",
    "validation.nationalId": "رقم الهوية",
    "validation.drivingLicense": "رخصة القيادة",
    "validation.fileSize": "حجم الملف",
    "validation.fileType": "نوع الملف",
    "validation.company": "الشركة",
  },
};
const ui = {
  en: {
    back: "Forms",
    flexible: "Flexible",
    builtIn: "Built-in",
    unsaved: "Unsaved",
    description: "Build a safe, responsive form with approved fields only.",
    usedBy: "Used by",
    discard: "Discard",
    save: "Save draft",
    publish: "Publish",
    published: "Published successfully.",
    restored: "Draft restored.",
    saved: "Draft saved.",
    discardConfirm: "Discard unsaved changes for this locale?",
    protected: "Protected built-in form.",
    protectedDescription:
      "File fields are legacy presentation-only: flexible mode never uploads or stores files. Structural edits switch this form to the controlled flexible renderer; styling, validation behavior, and executable code remain system-owned.",
    palette: "Field palette",
    paletteDescription:
      "Drag a field into the canvas, or use the accessible add buttons.",
    canvas: "Form canvas",
    canvasDescription: "fields · Drag handles or use move buttons",
    properties: "Field properties",
    propertiesDescription: "Localized copy and safe presentation rules",
    fieldKey: "Field key",
    type: "Type",
    width: "Width",
    required: "Required",
    label: "Label",
    placeholder: "Placeholder",
    help: "Help text",
    validationPreset: "Validation preset",
    none: "None",
    validationMessage: "Validation message",
    options: "Options",
    addOption: "Add option",
    duplicate: "Duplicate",
    remove: "Remove",
    selectField: "Select a field to edit its properties.",
    empty: "Choose a field from the palette to start.",
    moveUp: "Move up",
    moveDown: "Move down",
    drag: "Drag",
    newOption: "New option",
    fileProtected: "File (protected)",
    localeMissing: "This locale is not configured yet.",
    localeMissingDescription: "Create or seed this locale before editing it.",
  },
  ar: {
    back: "النماذج",
    flexible: "مرن",
    builtIn: "مدمج",
    unsaved: "غير محفوظ",
    description: "أنشئ نموذجاً آمناً ومتجاوباً باستخدام الحقول المعتمدة فقط.",
    usedBy: "مستخدم في",
    discard: "تجاهل",
    save: "حفظ المسودة",
    publish: "نشر",
    published: "تم النشر بنجاح.",
    restored: "تمت استعادة المسودة.",
    saved: "تم حفظ المسودة.",
    discardConfirm: "هل تريد تجاهل التغييرات غير المحفوظة لهذه اللغة؟",
    protected: "نموذج مدمج محمي.",
    protectedDescription:
      "حقول الملفات للعرض القديم فقط: الوضع المرن لا يرفع الملفات ولا يخزنها. تؤدي التعديلات الهيكلية إلى تحويل النموذج إلى العارض المرن المضبوط؛ بينما تبقى التنسيقات وسلوك التحقق والتنفيذ مملوكة للنظام.",
    palette: "لوحة الحقول",
    paletteDescription:
      "اسحب حقلاً إلى مساحة العمل أو استخدم أزرار الإضافة الميسّرة.",
    canvas: "مساحة النموذج",
    canvasDescription: "حقول · استخدم مقابض السحب أو أزرار النقل",
    properties: "خصائص الحقل",
    propertiesDescription: "النص المترجم وقواعد العرض الآمنة",
    fieldKey: "مفتاح الحقل",
    type: "النوع",
    width: "العرض",
    required: "مطلوب",
    label: "التسمية",
    placeholder: "النص البديل",
    help: "نص المساعدة",
    validationPreset: "إعداد التحقق",
    none: "بدون",
    validationMessage: "رسالة التحقق",
    options: "الخيارات",
    addOption: "إضافة خيار",
    duplicate: "تكرار",
    remove: "إزالة",
    selectField: "اختر حقلاً لتعديل خصائصه.",
    empty: "اختر حقلاً من اللوحة للبدء.",
    moveUp: "نقل لأعلى",
    moveDown: "نقل لأسفل",
    drag: "سحب",
    newOption: "خيار جديد",
    fileProtected: "ملف (محمي)",
    localeMissing: "هذه اللغة غير مهيأة بعد.",
    localeMissingDescription: "أنشئ هذه اللغة أو أضف بياناتها قبل تعديلها.",
  },
} as const;
const palette = genericFieldTypes.map((type) => ({
  type,
  label: typeNames[type],
}));
const choiceTypes = ["select", "radio", "checkbox"] as const;
function isChoiceType(type: string): type is (typeof choiceTypes)[number] {
  return choiceTypes.includes(type as (typeof choiceTypes)[number]);
}
const clone = <T,>(v: T): T => structuredClone(v);
function makeLocal(field: Field, locale: Locale): Local {
  return {
    fieldKey: field.key,
    locale,
    label: field.key,
    placeholder: null,
    helpText: null,
    validationMessage: null,
  };
}
const legacyPaths: Record<
  string,
  { label: string; placeholder?: string; validation?: string; options?: string }
> = {
  fullName: {
    label: "fields.fullName",
    placeholder: "placeholders.fullName",
    validation: "validation.fullNameMin",
  },
  phone: {
    label: "fields.phone",
    placeholder: "placeholders.phone",
    validation: "validation.phone",
  },
  message: {
    label: "fields.message",
    placeholder: "placeholders.message",
    validation: "validation.messageMin",
  },
  email: {
    label: "fields.email",
    placeholder: "placeholders.email",
    validation: "validation.email",
  },
  city: {
    label: "fields.city",
    placeholder: "placeholders.city",
    validation: "validation.city",
  },
  company: {
    label: "fields.company",
    placeholder: "placeholders.company",
    validation: "validation.company",
  },
  experienceYears: {
    label: "fields.experienceYears",
    placeholder: "selectPlaceholders.experienceYears",
    options: "experienceOptions",
  },
  transportType: {
    label: "fields.transportType",
    placeholder: "selectPlaceholders.transportType",
    options: "transportOptions",
  },
  nationalId: {
    label: "fields.nationalId",
    validation: "validation.nationalId",
  },
  drivingLicense: {
    label: "fields.drivingLicense",
    validation: "validation.drivingLicense",
  },
};
function setPath(
  target: Record<string, unknown>,
  path: string | undefined,
  value: unknown,
) {
  if (!path) return;
  const parts = path.split(".");
  let cursor = target;
  for (const part of parts.slice(0, -1))
    cursor =
      (cursor[part] as Record<string, unknown> | undefined) ??
      (cursor[part] = {});
  cursor[parts[parts.length - 1]] = value;
}
function sameStructure(a: NormalizedRevision, b: NormalizedRevision) {
  return (
    JSON.stringify(
      a.fields.map(
        ({ key, type, sortOrder, required, validationPreset, width }) => ({
          key,
          type,
          sortOrder,
          required,
          validationPreset,
          width,
        }),
      ),
    ) ===
      JSON.stringify(
        b.fields.map(
          ({ key, type, sortOrder, required, validationPreset, width }) => ({
            key,
            type,
            sortOrder,
            required,
            validationPreset,
            width,
          }),
        ),
      ) &&
    JSON.stringify(
      a.fields.map((f) => [
        f.key,
        (a.options[f.key] ?? []).map((o) => [o.key, o.sortOrder]),
      ]),
    ) ===
      JSON.stringify(
        b.fields.map((f) => [
          f.key,
          (b.options[f.key] ?? []).map((o) => [o.key, o.sortOrder]),
        ]),
      )
  );
}
function payload(
  rendererKey: FormRendererKey,
  normalized: NormalizedRevision,
  original: unknown,
  baseline: NormalizedRevision,
): unknown {
  // Generic revisions use the normalized contract as the source of truth. This
  // prevents round-trip loss of help text, validation copy, widths, options and form copy.
  if (rendererKey === "generic")
    return {
      ...clone(normalized),
      rendererKey: "generic",
      rendererMode: "flexible",
      templateKey: null,
    };
  if (!sameStructure(normalized, baseline))
    return {
      ...normalized,
      rendererKey,
      rendererMode: "flexible",
      templateKey: null,
    };
  const config = clone(original) as Record<string, unknown>;
  for (const field of normalized.fields) {
    const local = normalized.localizations.find(
      (x) => x.fieldKey === field.key,
    );
    const path = legacyPaths[field.key];
    if (!local || !path) continue;
    setPath(config, path.label, local.label);
    setPath(config, path.placeholder, local.placeholder);
    if (path.validation && local.validationMessage)
      setPath(config, path.validation, local.validationMessage);
    if (path.options)
      setPath(
        config,
        path.options,
        (normalized.options[field.key] ?? [])
          .sort((a, b) => a.sortOrder - b.sortOrder)
          .map((option) => option.label),
      );
  }
  if ("submit" in config)
    config.submit = normalized.copy.submitLabel ?? config.submit;
  if ("success" in config)
    config.success = normalized.copy.successMessage ?? config.success;
  return config;
}
function initialState(value: Initial) {
  return value
    ? {
        data: clone(value.normalized),
        baseline: clone(value.normalized),
        original: clone(value.config),
        token: value.revisionToken,
        dirty: false,
        busy: false,
        notice: "",
        error: "",
      }
    : null;
}
export function FormEditor({
  formId,
  formKey,
  rendererKey,
  kind,
  locales,
  references,
}: Props) {
  const idRef = useRef(0);
  const [locale, setLocale] = useState<Locale>(locales.ar ? "ar" : "en");
  const t = ui[locale];
  const localizedTypeNames = locale === "ar" ? arabicTypeNames : typeNames;
  const [states, setStates] = useState<
    Record<Locale, ReturnType<typeof initialState>>
  >({ ar: initialState(locales.ar), en: initialState(locales.en) });
  const [selected, setSelected] = useState(0);
  const [dragged, setDragged] = useState<string | null>(null);
  const state = states[locale];
  const field = state?.data.fields[selected];
  const mutate = (fn: (data: NormalizedRevision) => NormalizedRevision) =>
    setStates((s) =>
      state
        ? {
            ...s,
            [locale]: {
              ...state,
              data: fn(clone(state.data)),
              dirty: true,
              notice: "",
              error: "",
            },
          }
        : s,
    );
  const updateField = (changes: Partial<Field>) =>
    mutate((data) => {
      data.fields[selected] = { ...data.fields[selected], ...changes };
      return data;
    });
  function changeType(type: Field["type"]) {
    mutate((data) => {
      const current = data.fields[selected];
      current.type = type;
      // Choice fields always have a usable option list; every other field has
      // none. This keeps the normalized contract valid immediately after a type
      // change instead of leaving stale options for save/publish to reject.
      data.options[current.key] = isChoiceType(type)
        ? (data.options[current.key] ?? []).length
          ? data.options[current.key]
          : [
              {
                key: "option_1",
                sortOrder: 0,
                label: locale === "ar" ? "الخيار 1" : "Option 1",
              },
            ]
        : [];
      return data;
    });
  }
  const updateLocal = (key: string, changes: Partial<Local>) =>
    mutate((data) => {
      const i = data.localizations.findIndex(
        (x) => x.fieldKey === key && x.locale === locale,
      );
      if (i >= 0)
        data.localizations[i] = { ...data.localizations[i], ...changes };
      else
        data.localizations.push({ ...makeLocal(field!, locale), ...changes });
      return data;
    });
  function add(type: (typeof genericFieldTypes)[number]) {
    const key = `${type}_${(++idRef.current).toString(36)}`;
    mutate((data) => {
      const next = {
        key,
        type,
        sortOrder: data.fields.length,
        required: false,
        validationPreset: null,
        width: "full" as const,
      };
      data.fields.push(next);
      data.localizations.push({
        fieldKey: key,
        locale,
        label: localizedTypeNames[type],
        placeholder: null,
        helpText: null,
        validationMessage: null,
      });
      data.options[key] = ["select", "radio", "checkbox"].includes(type)
        ? [
            {
              key: "option_1",
              sortOrder: 0,
              label: locale === "ar" ? "الخيار 1" : "Option 1",
            },
          ]
        : [];
      return data;
    });
    setSelected(state?.data.fields.length ?? 0);
  }
  function move(from: number, to: number) {
    if (!state || to < 0 || to >= state.data.fields.length) return;
    mutate((data) => {
      const [item] = data.fields.splice(from, 1);
      data.fields.splice(to, 0, item);
      data.fields.forEach((x, i) => (x.sortOrder = i));
      return data;
    });
    setSelected(to);
  }
  function duplicate() {
    if (!field) return;
    const source = field;
    const sourceLocal = activeLocal;
    const sourceOptions = options;
    const key = `${source.key}_copy_${++idRef.current}`;
    mutate((data) => {
      data.fields.splice(selected + 1, 0, {
        ...source,
        key,
        sortOrder: selected + 1,
      });
      data.fields.forEach((x, i) => (x.sortOrder = i));
      data.localizations.push({
        ...(sourceLocal ?? makeLocal(source, locale)),
        fieldKey: key,
        locale,
      });
      data.options[key] = sourceOptions.map((x, i) => ({
        ...x,
        key: `${x.key}_copy`,
        sortOrder: i,
      }));
      return data;
    });
    setSelected(selected + 1);
  }
  function remove() {
    if (!field || field.type === "file") return;
    mutate((data) => {
      data.fields.splice(selected, 1);
      data.localizations = data.localizations.filter(
        (x) => x.fieldKey !== field.key,
      );
      delete data.options[field.key];
      data.fields.forEach((x, i) => (x.sortOrder = i));
      return data;
    });
    setSelected(Math.max(0, selected - 1));
  }
  async function save(action: "save" | "publish" | "discard") {
    if (!state) return;
    if (action === "discard" && !window.confirm(t.discardConfirm)) return;
    setStates((s) => ({
      ...s,
      [locale]: { ...state, busy: true, error: "", notice: "" },
    }));
    const submittedConfig = payload(
      rendererKey,
      state.data,
      state.original,
      state.baseline,
    );
    const result =
      action === "save"
        ? await saveFormDraft({
            formId,
            locale,
            revisionToken: state.token,
            config: submittedConfig,
          })
        : action === "publish"
          ? await publishForm({
              formId,
              locale,
              revisionToken: state.token,
              config: submittedConfig,
            })
          : await discardFormDraft(formId, locale, state.token);
    if (!result.ok) {
      setStates((s) => ({
        ...s,
        [locale]: { ...state, busy: false, error: result.message },
      }));
      return;
    }
    setStates((s) => ({
      ...s,
      [locale]: {
        ...state,
        busy: false,
        dirty: false,
        token: result.revisionToken,
        notice:
          action === "publish"
            ? t.published
            : action === "discard"
              ? t.restored
              : t.saved,
      },
    }));
  }
  const activeLocal = field
    ? state?.data.localizations.find(
        (x) => x.fieldKey === field.key && x.locale === locale,
      )
    : null;
  const options = field ? (state?.data.options[field.key] ?? []) : [];
  if (!state)
    return (
      <main className="mx-auto max-w-3xl p-10 text-center">
        <AlertCircle className="mx-auto text-destructive" />
        <h1 className="mt-3 font-semibold">{t.localeMissing}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {t.localeMissingDescription}
        </p>
      </main>
    );
  return (
    <main
      className="w-full px-4 py-6 md:px-8"
      dir={locale === "ar" ? "rtl" : "ltr"}
    >
      <div className="mx-auto max-w-[1500px] space-y-5">
        <header className="flex flex-col gap-4 border-b pb-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <Button
              variant="ghost"
              nativeButton={false}
              render={<Link href="/dashboard/forms" />}
            >
              <ArrowLeft />
              {t.back}
            </Button>
            <div className="mt-3 flex items-center gap-2">
              <h1 className="text-2xl font-semibold">{formKey}</h1>
              <Badge variant={kind === "system" ? "secondary" : "outline"}>
                {kind === "system" ? t.builtIn : t.flexible}
              </Badge>
              {state.dirty && <Badge variant="outline">{t.unsaved}</Badge>}
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              {t.description}
            </p>
            {references.length > 0 && (
              <p className="mt-2 text-xs text-muted-foreground">
                {t.usedBy}:{" "}
                {references
                  .map(
                    (reference) =>
                      `${reference.label} (${reference.locale.toUpperCase()})`,
                  )
                  .join(", ")}
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            <div className="flex rounded-lg border p-1">
              {(["ar", "en"] as Locale[]).map((l) => (
                <button
                  key={l}
                  disabled={!states[l]}
                  onClick={() => {
                    setLocale(l);
                    setSelected(0);
                  }}
                  className={`rounded-md px-3 py-1.5 text-sm ${locale === l ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                >
                  {l === "ar" ? "العربية" : "English"}
                  {states[l]?.dirty && " •"}
                </button>
              ))}
            </div>
            <Button
              variant="outline"
              disabled={state.busy || !state.dirty}
              onClick={() => save("discard")}
            >
              {t.discard}
            </Button>
            <Button
              variant="outline"
              disabled={state.busy || !state.dirty}
              onClick={() => save("save")}
            >
              <Save />
              {t.save}
            </Button>
            <Button disabled={state.busy} onClick={() => save("publish")}>
              <Check />
              {t.publish}
            </Button>
          </div>
        </header>
        {state.error && (
          <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
            {state.error}
          </div>
        )}
        {state.notice && (
          <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3 text-sm text-emerald-700">
            {state.notice}
          </div>
        )}
        {kind === "system" && (
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-900">
            <strong>{t.protected}</strong> {t.protectedDescription}
          </div>
        )}
        <div className="grid gap-5 lg:grid-cols-[220px_minmax(0,1fr)_340px]">
          <Card className="h-fit lg:sticky lg:top-4">
            <CardHeader>
              <CardTitle className="text-base">{t.palette}</CardTitle>
              <CardDescription>{t.paletteDescription}</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-2 lg:grid-cols-1">
              {palette.map((item) => (
                <Button
                  key={item.type}
                  variant="outline"
                  className="justify-start"
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData("text/plain", item.type);
                  }}
                  onClick={() => add(item.type)}
                  onDragEnd={() => undefined}
                >
                  <Plus />
                  {localizedTypeNames[item.type]}
                </Button>
              ))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t.canvas}</CardTitle>
              <CardDescription>
                {state.data.fields.length} {t.canvasDescription}
              </CardDescription>
            </CardHeader>
            <CardContent
              className="space-y-3"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                const type = e.dataTransfer.getData(
                  "text/plain",
                ) as (typeof genericFieldTypes)[number];
                if ((genericFieldTypes as readonly string[]).includes(type))
                  add(type);
              }}
            >
              {state.data.fields.map((item, i) => {
                const loc = state.data.localizations.find(
                  (x) => x.fieldKey === item.key && x.locale === locale,
                );
                return (
                  <div
                    key={item.key}
                    draggable
                    onDragStart={() => setDragged(item.key)}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={() => {
                      const from = state.data.fields.findIndex(
                        (x) => x.key === dragged,
                      );
                      if (from >= 0) move(from, i);
                      setDragged(null);
                    }}
                    onClick={() => setSelected(i)}
                    className={`group flex items-center gap-3 rounded-xl border p-3 transition ${selected === i ? "border-primary bg-primary/5 shadow-sm" : "hover:border-primary/40"}`}
                  >
                    <button
                      type="button"
                      className="cursor-grab rounded p-1 text-muted-foreground hover:bg-muted"
                      aria-label={`${t.drag} ${loc?.label ?? item.key}`}
                    >
                      <GripVertical />
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">
                        {loc?.label || item.key}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {localizedTypeNames[item.type]} · {item.width}{" "}
                        {item.required && `· ${t.required}`}
                      </p>
                    </div>
                    <div className="flex gap-1 opacity-70 group-hover:opacity-100">
                      <Button
                        size="icon-xs"
                        variant="ghost"
                        aria-label={t.moveUp}
                        disabled={i === 0}
                        onClick={(e) => {
                          e.stopPropagation();
                          move(i, i - 1);
                        }}
                      >
                        <ArrowUp />
                      </Button>
                      <Button
                        size="icon-xs"
                        variant="ghost"
                        aria-label={t.moveDown}
                        disabled={i === state.data.fields.length - 1}
                        onClick={(e) => {
                          e.stopPropagation();
                          move(i, i + 1);
                        }}
                      >
                        <ArrowDown />
                      </Button>
                    </div>
                  </div>
                );
              })}
              {!state.data.fields.length && (
                <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground">
                  {t.empty}
                </div>
              )}
            </CardContent>
          </Card>
          <Card className="h-fit lg:sticky lg:top-4">
            <CardHeader>
              <CardTitle className="text-base">{t.properties}</CardTitle>
              <CardDescription>{t.propertiesDescription}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {field ? (
                <>
                  <label className="grid gap-1.5 text-sm font-medium">
                    {t.fieldKey}
                    <Input
                      value={field.key}
                      readOnly
                      className="font-mono text-xs"
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-medium">
                    {t.type}
                    <select
                      value={field.type}
                      disabled={field.type === "file"}
                      onChange={(e) =>
                        changeType(e.target.value as Field["type"])
                      }
                      className="h-8 rounded-lg border border-input bg-transparent px-2 text-sm"
                    >
                      {Object.entries(typeNames)
                        .filter(
                          ([key]) => key !== "file" || field.type === "file",
                        )
                        .map(([key]) => (
                          <option key={key} value={key}>
                            {localizedTypeNames[key]}
                          </option>
                        ))}
                    </select>
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <label className="grid gap-1.5 text-sm font-medium">
                      {t.width}
                      <select
                        value={field.width}
                        onChange={(e) =>
                          updateField({
                            width: e.target.value as Field["width"],
                          })
                        }
                        className="h-8 rounded-lg border border-input bg-transparent px-2 text-sm"
                      >
                        {genericFieldWidths.map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label className="flex items-center gap-2 pt-6 text-sm">
                      <input
                        type="checkbox"
                        checked={field.required}
                        disabled={field.type === "file"}
                        onChange={(e) =>
                          updateField({ required: e.target.checked })
                        }
                      />
                      {t.required}
                    </label>
                  </div>
                  <label className="grid gap-1.5 text-sm font-medium">
                    {t.label} ({locale.toUpperCase()})
                    <Input
                      value={activeLocal?.label ?? ""}
                      onChange={(e) =>
                        updateLocal(field.key, { label: e.target.value })
                      }
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-medium">
                    {t.placeholder}
                    <Input
                      value={activeLocal?.placeholder ?? ""}
                      onChange={(e) =>
                        updateLocal(field.key, {
                          placeholder: e.target.value || null,
                        })
                      }
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-medium">
                    {t.help}
                    <textarea
                      value={activeLocal?.helpText ?? ""}
                      onChange={(e) =>
                        updateLocal(field.key, {
                          helpText: e.target.value || null,
                        })
                      }
                      className="min-h-16 rounded-lg border border-input bg-transparent px-3 py-2 text-sm"
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-medium">
                    {t.validationPreset}
                    <select
                      value={field.validationPreset ?? ""}
                      onChange={(e) =>
                        updateField({
                          validationPreset: (e.target.value ||
                            null) as Field["validationPreset"],
                        })
                      }
                      className="h-8 rounded-lg border border-input bg-transparent px-2 text-sm"
                    >
                      <option value="">{t.none}</option>
                      {genericValidationPresets.map((x) => (
                        <option key={x}>{validationNames[locale][x]}</option>
                      ))}
                    </select>
                  </label>
                  <label className="grid gap-1.5 text-sm font-medium">
                    {t.validationMessage}
                    <Input
                      value={activeLocal?.validationMessage ?? ""}
                      onChange={(e) =>
                        updateLocal(field.key, {
                          validationMessage: e.target.value || null,
                        })
                      }
                    />
                  </label>
                  {isChoiceType(field.type) && (
                    <div className="space-y-2">
                      <p className="text-sm font-medium">
                        {t.options} ({locale.toUpperCase()})
                      </p>
                      {options.map((option, i) => (
                        <Input
                          key={option.key}
                          value={option.label}
                          onChange={(e) =>
                            mutate((data) => {
                              data.options[field.key][i].label = e.target.value;
                              return data;
                            })
                          }
                        />
                      ))}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          mutate((data) => {
                            data.options[field.key].push({
                              key: `option_${data.options[field.key].length + 1}`,
                              sortOrder: data.options[field.key].length,
                              label: t.newOption,
                            });
                            return data;
                          })
                        }
                      >
                        <Plus />
                        {t.addOption}
                      </Button>
                    </div>
                  )}
                  <div className="flex gap-2 border-t pt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={field.type === "file"}
                      onClick={duplicate}
                    >
                      <Copy />
                      {t.duplicate}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      disabled={field.type === "file"}
                      onClick={remove}
                    >
                      <Trash2 />
                      {t.remove}
                    </Button>
                  </div>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">{t.selectField}</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
